package productsales;
/**
 *
 * @author Mutsh
 */

import java.util.Scanner;

public class ProductSalesApplication {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] products = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        String[] months = {"month 1", "month 2", "month 3"};
        int[][] sales = new int[products.length][months.length];

        for (int p = 0; p < products.length; p++) {
            for (int m = 0; m < months.length; m++) {
                sales[p][m] = readNonNegativeInt(input,
                    "Enter number of sales for " + months[m] + " for " + products[p] + ": ");
            }
            System.out.println();
        }

        Product product = new Product(products, sales);
        new PrintProduct(product).PrintReport();
        input.close();
    }

    private static int readNonNegativeInt(Scanner input, String prompt) {
        while (true) {
            System.out.print(prompt);
            if (input.hasNextInt()) {
                int value = input.nextInt();
                if (value >= 0) return value;
            } else {
                input.next();
            }
            System.out.println("Please enter a valid non-negative whole number.");
        }
    }
}
