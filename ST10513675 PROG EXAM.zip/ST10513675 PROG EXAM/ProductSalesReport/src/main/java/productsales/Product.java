package productsales;
/**
 *
 * @author Mutsh
 */

/** Stores monthly sales for each product and calculates sales statistics. */
public class Product implements IProduct {
    private final String[] productNames;
    private final int[][] monthlySales;

    public Product(String[] productNames, int[][] monthlySales) {
        if (productNames == null || monthlySales == null || productNames.length == 0
                || productNames.length != monthlySales.length) {
            throw new IllegalArgumentException("Product names and sales data must match.");
        }
        this.productNames = productNames.clone();
        this.monthlySales = new int[monthlySales.length][];
        for (int i = 0; i < monthlySales.length; i++) {
            if (monthlySales[i] == null || monthlySales[i].length == 0) {
                throw new IllegalArgumentException("Each product must have monthly sales data.");
            }
            this.monthlySales[i] = monthlySales[i].clone();
            for (int value : this.monthlySales[i]) {
                if (value < 0) throw new IllegalArgumentException("Sales cannot be negative.");
            }
        }
    }

    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int[] product : monthlySales) {
            for (int sales : product) total += sales;
        }
        return total;
    }

    @Override
    public double GetAverageProductSold() {
        int count = 0;
        for (int[] product : monthlySales) count += product.length;
        return count == 0 ? 0.0 : (double) GetTotalProductsSold() / count;
    }

    @Override
    public String GetMostPopularProduct() {
        int popularIndex = 0;
        int highestTotal = -1;
        for (int i = 0; i < monthlySales.length; i++) {
            int productTotal = 0;
            for (int sales : monthlySales[i]) productTotal += sales;
            if (productTotal > highestTotal) {
                highestTotal = productTotal;
                popularIndex = i;
            }
        }
        return productNames[popularIndex];
    }

    public String[] getProductNames() { return productNames.clone(); }
    public int[][] getMonthlySales() {
        int[][] copy = new int[monthlySales.length][];
        for (int i = 0; i < monthlySales.length; i++) copy[i] = monthlySales[i].clone();
        return copy;
    }
}
