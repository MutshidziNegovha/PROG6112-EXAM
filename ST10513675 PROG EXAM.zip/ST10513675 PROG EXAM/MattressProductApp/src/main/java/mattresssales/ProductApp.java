package mattresssales;
/**
 *
 * @author Mutsh
 */
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/** GUI for capturing mattress sales and recording the calculated amounts. */
public class ProductApp extends JFrame {
    private final JTextField customerNameField = new JTextField(22);
    private final JComboBox<String> productComboBox = new JComboBox<>(new String[] {
        "Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"
    });
    private final JTextField priceField = new JTextField(22);
    private final DecimalFormat moneyFormat = new DecimalFormat("0.0#");

    public ProductApp() {
        super("Product App");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setJMenuBar(createMenuBar());
        add(createForm(), BorderLayout.CENTER);
        setSize(570, 330);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(event -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(event -> processSale());
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(event -> clearForm());
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        return menuBar;
    }

    private JPanel createForm() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 12, 12, 12);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        addFormRow(panel, gbc, 0, "Customer Name:", customerNameField);
        addFormRow(panel, gbc, 1, "Select Product:", productComboBox);
        addFormRow(panel, gbc, 2, "Enter Price:", priceField);

        JButton processButton = new JButton("PROCESS");
        processButton.addActionListener(event -> processSale());
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.weightx = 1;
        panel.add(processButton, gbc);
        return panel;
    }

    private void addFormRow(JPanel panel, GridBagConstraints gbc, int row,
                            String label, java.awt.Component field) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        gbc.weightx = 1;
        panel.add(field, gbc);
    }

    private void processSale() {
        String customerName = customerNameField.getText().trim();
        String productName = (String) productComboBox.getSelectedItem();
        String priceText = priceField.getText().trim();

        if (customerName.isEmpty()) {
            showError("Please enter the customer's name.");
            customerNameField.requestFocus();
            return;
        }
        if (priceText.isEmpty()) {
            showError("Please enter the product price.");
            priceField.requestFocus();
            return;
        }

        final double price;
        try {
            price = Double.parseDouble(priceText);
            if (!Double.isFinite(price) || price <= 0) {
                showError("Please enter a valid price greater than zero.");
                priceField.requestFocus();
                return;
            }
        } catch (NumberFormatException exception) {
            showError("The product price must be a number.");
            priceField.requestFocus();
            return;
        }

        ProductCalculations calculations = new ProductCalculations(price);
        double vat = calculations.GetVat();
        double commission = calculations.GetCommission();
        double total = calculations.GetTotal();

        String result = "Customer Name: " + customerName
                + "\nProduct: " + productName
                + "\nVAT: R " + moneyFormat.format(vat)
                + "\nCOMMISSION: R " + moneyFormat.format(commission)
                + "\nTOTAL: R " + moneyFormat.format(total);

        try {
            saveSale(customerName, productName, vat, commission, total);
            JOptionPane.showMessageDialog(this, result, "Message", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException exception) {
            JOptionPane.showMessageDialog(this,
                    "The sale was calculated, but data.txt could not be saved.\n" + exception.getMessage(),
                    "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void saveSale(String customerName, String productName,
                          double vat, double commission, double total) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data.txt", true))) {
            writer.write("DATA LOG");
            writer.newLine();
            writer.write("****************************************");
            writer.newLine();
            writer.write("Customer Name: " + customerName);
            writer.newLine();
            writer.write("Product: " + productName);
            writer.newLine();
            writer.write("VAT: R " + moneyFormat.format(vat));
            writer.newLine();
            writer.write("COMMISSION: R " + moneyFormat.format(commission));
            writer.newLine();
            writer.write("TOTAL: R " + moneyFormat.format(total));
            writer.newLine();
            writer.write("****************************************");
            writer.newLine();
        }
    }

    private void clearForm() {
        customerNameField.setText("");
        priceField.setText("");
        productComboBox.setSelectedIndex(0);
        customerNameField.requestFocus();
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Input Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
