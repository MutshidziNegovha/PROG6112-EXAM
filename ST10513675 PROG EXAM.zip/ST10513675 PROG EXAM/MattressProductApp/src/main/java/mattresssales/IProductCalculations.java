package mattresssales;
/**
 *
 * @author Mutsh
 */
public interface IProductCalculations {
    double GetVat();
    double GetCommission();
    double GetTotal();
}
