package mattresssales;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class ProductCalculationsTest {
    @Test
    void GetVat_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calculations = new ProductCalculations(3500.0);
        assertEquals(525.0, calculations.GetVat(), 0.001);
    }

    // Additional tests for the other two calculation methods.
    @Test
    void GetCommission_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calculations = new ProductCalculations(3500.0);
        assertEquals(175.0, calculations.GetCommission(), 0.001);
    }

    @Test
    void GetTotal_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calculations = new ProductCalculations(3500.0);
        assertEquals(4200.0, calculations.GetTotal(), 0.001);
    }
}
